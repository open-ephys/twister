1. Drill File = twister.drd
2. Bottom Soldermask = twister.smb
3. Bottom Copper Layer = twister.bot
4. Top Copper Layer =  twister.top
5. Top Soldermask Layer = twister.smt
6. Top Silkscreen Layer = twister.slk
7. Board Outline = twister.oln